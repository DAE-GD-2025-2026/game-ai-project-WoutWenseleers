﻿#include "GeoUtilities.h"
